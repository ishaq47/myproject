<!-- <?php


// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the login form is submitted
if (isset($_POST['submit'])) {
    // Get the input values from the login form
    $email = $_POST['email'];
    $password = $_POST['password'];

    // SQL query to check if the email and password match
    $sql = "SELECT * FROM registration WHERE email = '$email' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Login successful
        echo "Login successful!";
        // Perform any additional actions or redirect to another page
    } else {
        // Login failed
        echo "Invalid email or password!";
    }
}

$conn->close();
header("Location: ../home.html");
exit;
?> -->
<!-- <?php
$name= $_POST['name'];
$email= $_POST['email'];
$password= $_POST['password'];
$cpassword= $_POST['cpassword'];
// data base sonnection
$conn = new mysqli('localhost','root','','users');
if($conn->connect_error)
{
    die('connection failed:' . $conn->connect_error);

}
else {
$stmt= $conn->prepare("insert into registration(name ,email ,password ,cpassword) values(?,?,?,?)");
$stmt->bind_param("ssss",$name ,$email,$password,$cpassword);
$stmt->execute();
echo "<script> alert(successfully registered) </script> ";
$stmt->close();
$conn->close();

header("location: ../login_form.html");
exit;
}
?> -->
