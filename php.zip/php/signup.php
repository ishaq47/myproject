<?php
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$cpassword = $_POST['cpassword'];

// Database connection
$conn = new mysqli('localhost', 'root', '', 'users');
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
} 
else {
    $stmt = $conn->prepare("insert into registration (name, email, password, cpassword) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $password, $cpassword);
    $stmt->execute();
    "<script> alert('Successfully registered'); </script>";
    $stmt->close();
    $conn->close();

   
    header('location: ../login_form.html');
    exit;
}
?>