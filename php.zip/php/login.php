<?php


// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Retrieve the form data
  $email = $_POST["email"];
  $password = $_POST["password"];

  // // Validate the form data
  // $errors = array();

  // // Validate email
  // if (empty($email)) {
  //   $errors[] = "Email is required";
  // } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  //   $errors[] = "<script> alert('Invalid email format'); </script>";
  // }

  // // Validate password
  // if (empty($password)) {
  //   $errors[] = "Password is required";
  // } elseif (strlen($password) < 6) {
  //   $errors[] = "<script> alert('Password should be at least 6 characters long'); </script>";
  // }

  // If there are no errors, perform further processing (e.g., check against database, authenticate user)
  if (empty($errors)) {
    // Connect to MySQL database
    $conn = new mysqli('localhost', 'root', '', 'users');

    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute SQL query
    $sql = "SELECT * FROM registration WHERE email = '$email' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      // Authentication successful, redirect to dashboard or home page
      header("Location: /home.html");
      exit;
    } else {
      // Authentication failed, display an error message
      $errors[] = "<script> alert('Invalid email or password');</script>";
    }

    // Close the database connection
    $conn->close();
  }
}
?>
