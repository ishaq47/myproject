function validate() {
    var email = document.getElementById("email")
    var password = document.getElementById("password")
    if (email.value.trim() == "" || password.value.trim() == "") {
      alert("fill the blank spaces");
      return false;
    }
    else {
      true;
    }

  }