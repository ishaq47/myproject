// function validate() {
//     var email = document.getElementById("email")
//     var password = document.getElementById("password")
//     if (email.value.trim() == "" || password.value.trim() == "" )
//      {
//       alert("fill the blank spaces");
//      return false;
//     }
//     else {
//       true;
//     }
  
     
  
//   }
function validate() {
  var name = document.getElementById("name");
  var email = document.getElementById("email");
  var password = document.getElementById("password");
  var cpassword = document.getElementById("cpassword");

  // Check if all fields are filled in
  if (name.value.trim() === "" || email.value.trim() === "" || password.value.trim() === "" || cpassword.value.trim() === "") {
    alert("Please fill in all fields.");
    return false;
  }
 

  // Check if password and confirm password match
  if (password.value != cpassword.value) {
    alert("Passwords do not match.");
    return false;
  }
  

  // Check if password meets the minimum requirements (e.g., at least 8 characters)
  if (password.value.length < 8) {
    alert("Password must be at least 8 characters long.");
    return false;
  }


  return true; // Submit the form
}

  